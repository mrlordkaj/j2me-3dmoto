/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import util.GraphicButton;
import util.ImageHelper;

/**
 *
 * @author Thinh
 */
public class Setting extends GamePage implements CommandListener {
    private static final byte TAB_SPRAY = 1;
    private static final byte TAB_UPGRADE = 2;
    private static final byte TAB_CONTROL = 3;
    private static final byte TAB_SYSTEM = 4;
    
    private Image imgSettingFg;
    
    private GraphicButton[] tab;
    private byte currentTab;
    private String tabTitle;
    private SettingPage settingPage;
    
    private byte tempSprayColor;
    private boolean tempIsTouchOnly;
    
    private Main parent;
    
    public boolean getTempIsTouchOnly() { return tempIsTouchOnly; }
    public byte getTempSprayColor() { return tempSprayColor; }
    public void setTempIsTouchOnly(boolean value) { tempIsTouchOnly = value; }
    public void setTempSprayColor(byte value) { tempSprayColor = value; }
    
    public Setting(Main parent) {
        super();
        this.parent = parent;
        
        tempSprayColor = parent.sprayColor;
        tempIsTouchOnly = parent.isTouchOnly;
        
        schedule = 100;
        new Thread(this).start();
        
        prepareResource();
        
        activeTab(TAB_SPRAY);
        
        addCommand(new Command("Back", Command.BACK, 1));
        setCommandListener(this);
    }
    
    private void prepareResource() {
        imgSettingFg = ImageHelper.loadImage("/images/settingfg.png");
        
        /*
        tab = new GraphicButton[] {
            new GraphicButton("/images/tabspray.png", TAB_SPRAY, 15, 63, 46, 22),
            new GraphicButton("/images/tabupgrade.png", TAB_UPGRADE, 62, 63, 46, 22),
            new GraphicButton("/images/tabcontrol.png", TAB_CONTROL, 109, 63, 46, 22),
            new GraphicButton("/images/tabsystem.png", TAB_SYSTEM, 156, 63, 46, 22)
        };
        */ //for 240x320
        tab = new GraphicButton[] {
            new GraphicButton("/images/tabspray.png", TAB_SPRAY, 15, 82, 46, 22),
            new GraphicButton("/images/tabupgrade.png", TAB_UPGRADE, 62, 82, 46, 22),
            new GraphicButton("/images/tabcontrol.png", TAB_CONTROL, 109, 82, 46, 22),
            new GraphicButton("/images/tabsystem.png", TAB_SYSTEM, 156, 82, 46, 22)
        };
        //for 240x400
        
        isLoading = false;
    }
    
    public void paint(Graphics g) {
        if(isLoading) return;
        
        if(settingPage != null) settingPage.paint(g);
        g.drawImage(imgSettingFg, 0, 0, Graphics.LEFT | Graphics.TOP);
        
        for(byte i = 0; i < tab.length; i++) {
            tab[i].paint(g);
        }
        
        g.setColor(0x00000);
        /*
        switch(currentTab) {
            case TAB_SPRAY:
                g.drawLine(68,83,203,83);
                break;
                
            case TAB_UPGRADE:
                g.drawLine(15,83,67,83);
                g.drawLine(113,83,203,83);
                break;
                
            case TAB_CONTROL:
                g.drawLine(15,83,112,83);
                g.drawLine(159,83,203,83);
                break;
                
            case TAB_SYSTEM:
                g.drawLine(15,83,158,83);
                break;
        }
        */ //for 240x320
        switch(currentTab) {
            case TAB_SPRAY:
                g.drawLine(68,102,203,102);
                break;
                
            case TAB_UPGRADE:
                g.drawLine(15,102,67,102);
                g.drawLine(113,102,203,102);
                break;
                
            case TAB_CONTROL:
                g.drawLine(15,102,112,102);
                g.drawLine(159,102,203,102);
                break;
                
            case TAB_SYSTEM:
                g.drawLine(15,102,158,102);
                break;
        }
        g.setColor(0xffffff);
        g.setFont(Play.BOLD_MEDIUM);
        g.drawString(tabTitle, Main.SCREENSIZE_WIDTH/2+1, 131, Graphics.HCENTER | Graphics.BASELINE);
        g.setColor(0xdb601d);
        g.drawString(tabTitle, Main.SCREENSIZE_WIDTH/2, 130, Graphics.HCENTER | Graphics.BASELINE);
        //for 240x400
    }

    protected void update() {
        if(isLoading) return;
        
        if(settingPage != null) settingPage.update();
    }
    
    protected void pointerPressed(int x, int y) {
        if(isLoading) return;
        
        for(byte i = 0; i < tab.length; i++) {
            if(tab[i].contains(x, y)) {
                activeTab(tab[i].getCommand());
                break;
            }
        }
        
        if(settingPage != null) settingPage.pointerPressed(x, y);
        
        if(y > Main.SCREENSIZE_HEIGHT - 40) {
            if(x < 80) {
                //apply
                parent.isTouchOnly = tempIsTouchOnly;
                parent.sprayColor = tempSprayColor;
                parent.saveSetting();
                parent.gotoMainMenu();
            } else if(x > Main.SCREENSIZE_WIDTH-80) {
                //cancel
                parent.gotoMainMenu();
            }
        }
    }
    
    private void activeTab(byte tabId) {
        isLoading = true;
        
        for(byte i = 0; i < tab.length; i++) {
            tab[i].active = false;
            if(tab[i].getCommand() == tabId) tab[i].active = true;
            else tab[i].active = false;
        }
        
        if(tabId != currentTab) {
            currentTab = tabId;
            
            if(settingPage != null) {
                settingPage.dispose();
                settingPage = null;
            }
            
            switch(currentTab) {
                case TAB_SPRAY:
                    settingPage = new SettingSpray(this);
                    tabTitle = "SPRAY";
                    break;
                    
                case TAB_UPGRADE:
                    settingPage = new SettingUpgrade(this);
                    tabTitle = "UPGRADE";
                    break;
                    
                case TAB_CONTROL:
                    settingPage = new SettingControl(this);
                    tabTitle = "CONTROL";
                    break;
                    
                case TAB_SYSTEM:
                    settingPage = new SettingSystem(this);
                    tabTitle = "SYSTEM";
                    break;
            }
        }
        
        isLoading = false;
    }
    
    public void commandAction(Command c, Displayable d) {
        if(c.getCommandType() == Command.BACK) {
            parent.gotoMainMenu();
        }
    }
}
