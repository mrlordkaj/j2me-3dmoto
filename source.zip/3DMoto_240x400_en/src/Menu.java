/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.io.ConnectionNotFoundException;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import util.GraphicButton;
import util.ImageHelper;

/**
 *
 * @author Thinh
 */
public class Menu extends GamePage implements CommandListener {
    private static final int STATE_NONE = 0;
    private static final int STATE_SPLASH = 1;
    private static final int STATE_MENU = 2;
    private static final int STATE_HELP = 3;
    
    private static final byte COMMAND_NONE = 0;
    private static final byte COMMAND_PLAY = 1;
    private static final byte COMMAND_SETTING = 2;
    private static final byte COMMAND_LEADERBOARD = 3;
    private static final byte COMMAND_HELP = 4;
    private static final byte COMMAND_RATE = 5;
    private static final byte COMMAND_QUIT = 6;
    
    private static final Command backCommand = new Command("Back", Command.BACK, 1);
    
    private Image backgroundImg, oivLogoImg, helpImg;
    private GraphicButton[] button;
    private byte activeCommand = COMMAND_NONE;
    
    private int state = STATE_NONE;
    private int splashTimeline;

    private Main parent;
    private Alert alert;
    
    public Menu(boolean showSplash, Main _parent) {
        super();
        parent = _parent;
        
        schedule = 40;
        new Thread(this).start();
        
        prepareResource();
        
        if(showSplash) state = STATE_SPLASH;
        else state = STATE_MENU;
    }
    
    private void prepareResource() {
        backgroundImg = ImageHelper.loadImage("/images/mainmenu.png");
        oivLogoImg = ImageHelper.loadImage("/images/logooiv.png");
        if(parent.isTouchOnly) helpImg = ImageHelper.loadImage("/images/helpb.png");
        else helpImg = ImageHelper.loadImage("/images/helpa.png");
        
        /*
        button = new GraphicButton[] {
            new GraphicButton("/images/btnplay.png", COMMAND_PLAY, 69, 153, 102, 102),
            new GraphicButton("/images/btnsetting.png", COMMAND_SETTING, 4, 250, 40, 40),
            new GraphicButton("/images/btnleaderboard.png", COMMAND_LEADERBOARD, 52, 250, 40, 40),
            new GraphicButton("/images/btnhelp.png", COMMAND_HELP, 100, 250, 40, 40),
            new GraphicButton("/images/btnrate.png", COMMAND_RATE, 148, 250, 40, 40),
            new GraphicButton("/images/btnquit.png", COMMAND_QUIT, 196, 250, 40, 40)
        };
        */ //for 240x320
        button = new GraphicButton[] {
            new GraphicButton("/images/btnplay.png", COMMAND_PLAY, 69, 213, 102, 102),
            new GraphicButton("/images/btnsetting.png", COMMAND_SETTING, 4, 320, 40, 40),
            new GraphicButton("/images/btnleaderboard.png", COMMAND_LEADERBOARD, 52, 320, 40, 40),
            new GraphicButton("/images/btnhelp.png", COMMAND_HELP, 100, 320, 40, 40),
            new GraphicButton("/images/btnrate.png", COMMAND_RATE, 148, 320, 40, 40),
            new GraphicButton("/images/btnquit.png", COMMAND_QUIT, 196, 320, 40, 40)
        };
        //for 240x400
        
        isLoading = false;
    }
    
    public void paint(Graphics g) {
        if(isLoading) return;
        
        switch(state) {
            case STATE_SPLASH:
                g.drawImage(oivLogoImg, 0, 0, Graphics.LEFT | Graphics.TOP);
                break;
                
            case STATE_MENU:
                g.drawImage(backgroundImg, 0, 0, Graphics.LEFT | Graphics.TOP);
                for(byte i = 0; i < button.length; i++) {
                    button[i].paint(g);
                }
                break;
                
            case STATE_HELP:
                g.drawImage(helpImg, 0, 0, Graphics.LEFT | Graphics.TOP);
                break;
        }
    }
    
    protected void pointerPressed(int x, int y) {
        if(isLoading || state != STATE_MENU) return;
        
        setActiveCommand(x, y);
    }
    
    protected void pointerDragged(int x, int y) {
        if(isLoading || state != STATE_MENU) return;
        
        setActiveCommand(x, y);
    }
    
    protected void pointerReleased(int x, int y) {
        if(isLoading || state == STATE_SPLASH) return;
        
        if(state == STATE_MENU) {
            switch(activeCommand) {
                case COMMAND_PLAY:
                    parent.gotoGame();
                    break;
                    
                case COMMAND_SETTING:
                    parent.gotoSetting();
                    break;
                    
                case COMMAND_LEADERBOARD:
                    alert = new Alert("Not available!", "Leaderboard is not ready by now.", null, AlertType.INFO);
                    alert.addCommand(new Command("Okay", Command.OK, 1));
                    alert.setTimeout(Alert.FOREVER);
                    alert.setCommandListener(this);
                    parent.display.setCurrent(alert, this);
                    break;

                case COMMAND_HELP:
                    state = STATE_HELP;
                    addCommand(backCommand);
                    setCommandListener(this);
                    break;
                    
                case COMMAND_RATE:
                    try {
                        //parent.platformRequest("http://store.ovi.mobi/content/383612"); //240x320
                        parent.platformRequest("http://store.ovi.mobi/content/383612/comments/add"); //240x400
                    } catch (ConnectionNotFoundException ex) {}
                    break;

                case COMMAND_QUIT:
                    alert = new Alert("Quit", "Are you sure you want to quit?", null, AlertType.WARNING);
                    alert.addCommand(new Command("Quit", Command.EXIT, 1));
                    alert.addCommand(new Command("Cancel", Command.CANCEL, 1));
                    alert.setTimeout(Alert.FOREVER);
                    alert.setCommandListener(this);
                    parent.display.setCurrent(alert, this);
                    break;
            }

            for(byte i = 0; i < button.length; i++) {
                button[i].active = false;
            }
            activeCommand = COMMAND_NONE;
        } else if(state == STATE_HELP) {
            state = STATE_MENU;
        }
    }
    
    private void setActiveCommand(int x, int y) {
        activeCommand = COMMAND_NONE;
        for(byte i = 0; i < button.length; i++) {
            button[i].active = false;
            if(button[i].contains(x, y)) {
                button[i].active = true;
                activeCommand = button[i].getCommand();
            }
        }
    }
    
    protected void update() {
        if(state == STATE_SPLASH) {
            if(++splashTimeline > 50) state = STATE_MENU;
        }
    }

    public void commandAction(Command c, Displayable d) {
        switch(c.getCommandType()) {
            case Command.EXIT:
                parent.notifyDestroyed();
                break;
                
            case Command.CANCEL:
            case Command.OK:
                parent.display.setCurrent(this);
                alert = null;
                break;
                
            case Command.BACK:
                if(state == STATE_HELP) {
                    state = STATE_MENU;
                    removeCommand(backCommand);
                    setCommandListener(null);
                }
                break;
        }
        alert = null;
    }

}
