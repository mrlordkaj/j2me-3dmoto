/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.nokia.mid.ui.DeviceControl;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import javax.microedition.io.Connector;
import javax.microedition.lcdui.Display;
import javax.microedition.midlet.*;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.sensor.ChannelInfo;
import javax.microedition.sensor.SensorConnection;
import javax.microedition.sensor.SensorInfo;
import javax.microedition.sensor.SensorManager;

/**
 * @author Thinh
 */
public class Main extends MIDlet {
    public static final int SCREENSIZE_WIDTH = 240;
    public static final int SCREENSIZE_HEIGHT = 400;
    public static final String RMS_SCORE = "openitvn3dmoto_score";
    public static final String RMS_SETTING = "openitvn3dmoto_setting";
    private static final byte SETTING_SPRAY = 1;
    private static final byte SETTING_CONTROL = 2;
    private static final int BUFFER_SIZE = 3;
    private static SensorConnection iConnection;
    
    public Display display;
    private GamePage child;
    
    public boolean isTouchOnly = false;
    public byte sprayColor = 0;

    public void startApp() {
        try {
            RecordStore rs = RecordStore.openRecordStore(RMS_SCORE, true);
            if (rs.getNumRecords() != 1) {
                rs.closeRecordStore();
                RecordStore.deleteRecordStore(RMS_SCORE);

                rs = RecordStore.openRecordStore(RMS_SCORE, true);
                byte[] writer = "0".getBytes();
                rs.addRecord(writer, 0, writer.length);
                rs.closeRecordStore();
                System.out.println("Reset score.");
            }
        } catch (RecordStoreException ex) {}
        
        try {
            RecordStore rs = RecordStore.openRecordStore(RMS_SETTING, true);
            if (rs.getNumRecords() != 2) {
                rs.closeRecordStore();
                RecordStore.deleteRecordStore(RMS_SETTING);

                rs = RecordStore.openRecordStore(RMS_SETTING, true);
                byte[] writer = "0".getBytes();
                rs.addRecord(writer, 0, writer.length); //dòng 1 là màu xe
                rs.addRecord(writer, 0, writer.length); //dòng 2 là chế độ điều kiển
                rs.closeRecordStore();
                System.out.println("Reset setting.");
            }
        } catch (RecordStoreException ex) {}
        
        try {
            RecordStore rs = RecordStore.openRecordStore(Main.RMS_SETTING, true);
            sprayColor = Byte.parseByte(new String(rs.getRecord(SETTING_SPRAY)));
            isTouchOnly = new String(rs.getRecord(SETTING_CONTROL)).equals("0");
            rs.closeRecordStore();
        } catch (RecordStoreException ex) {}
        
        prepareAccelerometer();
        
        display = Display.getDisplay(this);
        
        child = new Menu(true, this);
        display.setCurrent(child);
        
        /*
        new Timer().schedule(new TimerTask() {
            public void run() {
                DeviceControl.setLights(0, 100);
            }
        }, 0, 29000);
        */ //for 240x320
        new Timer().schedule(new TimerTask() {
            public void run() {
                System.gc();
                DeviceControl.setLights(0, 100);
            }
        }, 0, 5000);
        //for 240x400
    }
    
    private void prepareAccelerometer() {
        try {
            SensorInfo[] infos = SensorManager.findSensors("acceleration", null);
            if(infos.length == 0) return;

            // INT data type is preferred
            int i = 0;
            for(i = 0; i < infos.length && infos[i].getChannelInfos()[0].getDataType() != ChannelInfo.TYPE_INT; i++);

            iConnection = (i==infos.length) ? (SensorConnection)Connector.open(infos[0].getUrl()):
                        (SensorConnection)Connector.open(infos[i].getUrl());
        } catch (Exception ex) {
            isTouchOnly = true;
        }
    }
    
    public void pauseApp() {
    }
    
    public void destroyApp(boolean unconditional) {
        if(Play.class == child.getClass()) {
            child.dispose();
        }
        
        try {
            if(iConnection != null) iConnection.close();
        } catch (IOException ex) {}
    }
    
    public void gotoMainMenu() {
        child.dispose();
        child = null;
        
        child = new Menu(false, this);
        display.setCurrent(child);
    }
    
    public void gotoGame() {
        child.dispose();
        child = null;
        
        child = new Play(this);
        if(iConnection != null && !isTouchOnly) iConnection.setDataListener((Play)child, BUFFER_SIZE);
        display.setCurrent(child);
    }
    
    public void gotoSetting() {
        child.dispose();
        child = null;
        
        child = new Setting(this);
        display.setCurrent(child);
    }
    
    public void saveSetting() {
        try {
            RecordStore rs = RecordStore.openRecordStore(RMS_SETTING, false);
            byte[] writer = Integer.toString(sprayColor).getBytes();
            rs.setRecord(SETTING_SPRAY, writer, 0, writer.length);
            writer = (isTouchOnly?"0":"1").getBytes();
            rs.setRecord(SETTING_CONTROL, writer, 0, writer.length);
            rs.closeRecordStore();
        } catch (RecordStoreException ex) {
        }
    }
}
