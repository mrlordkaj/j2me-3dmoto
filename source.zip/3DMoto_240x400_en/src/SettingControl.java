/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Graphics;
import util.GraphicButton;

/**
 *
 * @author Thinh
 */
public class SettingControl extends SettingPage {
    private static final byte CONTROL_TOUCH = 0;
    private static final byte CONTROL_ACCEL = 1;
    
    private boolean isTouchOnly;
    private GraphicButton[] button;
    
    public SettingControl(Setting parent) {
        super(parent);
    }

    protected void prepareResource() {
        /*
        button = new GraphicButton[] {
            new GraphicButton("/images/controltouchscreenonly.png", CONTROL_TOUCH, 25, 90, 190, 90),
            new GraphicButton("/images/controlaccelerometer.png", CONTROL_ACCEL, 25, 188, 190, 90)
        };
        */ //for 240x320
        button = new GraphicButton[] {
            new GraphicButton("/images/controltouchscreenonly.png", CONTROL_TOUCH, 25, 145, 190, 90),
            new GraphicButton("/images/controlaccelerometer.png", CONTROL_ACCEL, 25, 253, 190, 90)
        };
        //for 240x400
        
        isTouchOnly = parent.getTempIsTouchOnly();
        if(isTouchOnly) button[0].active = true;
        else button[1].active = true;
    }

    public void paint(Graphics g) {
        g.setColor(0x00b4ff);
        g.fillRect(0, 0, Main.SCREENSIZE_WIDTH, Main.SCREENSIZE_HEIGHT);
        
        button[0].paint(g);
        button[1].paint(g);
    }

    public void pointerPressed(int x, int y) {
        if(button[0].contains(x, y) && !isTouchOnly) {
            button[0].active = true;
            button[1].active = false;
            isTouchOnly = true;
            parent.setTempIsTouchOnly(true);
        } else if(button[1].contains(x, y) && isTouchOnly) {
            button[0].active = false;
            button[1].active = true;
            isTouchOnly = false;
            parent.setTempIsTouchOnly(false);
        }
    }

    public void update() {
        
    }

    public void dispose() {
        button[0] = null;
        button[1] = null;
        button = null;
    }
}
