/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Graphics;
import javax.microedition.m3g.Appearance;
import javax.microedition.m3g.Background;
import javax.microedition.m3g.Camera;
import javax.microedition.m3g.Graphics3D;
import javax.microedition.m3g.Group;
import javax.microedition.m3g.Image2D;
import javax.microedition.m3g.Light;
import javax.microedition.m3g.Mesh;
import javax.microedition.m3g.Texture2D;
import javax.microedition.m3g.World;
import util.ColorPicker;
import util.ImageHelper;
import util.ModelHelper;

/**
 *
 * @author Thinh
 */
public class SettingSpray extends SettingPage {
    private Graphics3D mGraphics3D = Graphics3D.getInstance();
    private World mWorld;
    private Mesh mBike;
    private Group mgBike;
    
    private byte sprayColor;
    private ColorPicker[] colorButton;
    
    public SettingSpray(Setting parent) {
        super(parent);
    }
    
    protected void prepareResource() {
        mWorld = new World();
        
        //tạo bảng màu
        colorButton = new ColorPicker[] {
            new ColorPicker(0, 40, 186),
            new ColorPicker(1, 100, 186),
            new ColorPicker(2, 160, 186),
            new ColorPicker(3, 40, 236),
            new ColorPicker(4, 100, 236),
            new ColorPicker(5, 160, 236),
        };
        //for 240x320
        /*
        colorButton = new ColorPicker[] {
            new ColorPicker(0, 40, 258),
            new ColorPicker(1, 100, 258),
            new ColorPicker(2, 160, 258),
            new ColorPicker(3, 40, 312),
            new ColorPicker(4, 100, 312),
            new ColorPicker(5, 160, 312),
        };
        */ //for 240x400
        
        //tạo mẫu xe
        World bikeRes = ModelHelper.loadWorld("/models/bike.res");
        mBike = (Mesh)ModelHelper.extractNode(2, bikeRes);
        bikeRes = null;
        sprayColor = parent.getTempSprayColor();
        Image2D img2D = new Image2D(Image2D.RGB, ImageHelper.loadImage("/models/bike"+sprayColor+".png"));
        Texture2D tex2D = new Texture2D(img2D);
        Appearance mAppearance = new Appearance();
        mAppearance.setTexture(0, tex2D);
        mBike.setAppearance(0, mAppearance);
        mBike.setOrientation(90, 0, 0, 1);
        mBike.postRotate(90, 0, 1, 0);
        mBike.postRotate(-90, 0, 0, 1);
        mgBike = new Group();
        mgBike.addChild(mBike);
        mWorld.addChild(mgBike);
        mgBike.postRotate(135, 0, 1, 0);
        
        //khởi tạo camera
        Camera mCamera = new Camera();
        mCamera.setPerspective(
            60,
            (float)Main.SCREENSIZE_WIDTH / (float)Main.SCREENSIZE_HEIGHT,
            100,
            2000
        );
        mWorld.addChild(mCamera);
        mWorld.setActiveCamera(mCamera);
        mCamera.setOrientation(-35, 1, 0, 0);
        mCamera.setTranslation(0, 160, 250); //for 240x320
        //mCamera.setTranslation(0, 180, 250); //for 240x400
        
        //tạo nền
        Background mBackground = new Background();
        mBackground.setColor(0x00b4ff);
        mWorld.setBackground(mBackground);
        
        //khởi tạo nguồn sáng
        Light light1 = new Light();
        light1.setTranslation(0, 400, 0);
        light1.setColor(0xffffff);
        light1.setMode(Light.AMBIENT);
        light1.setIntensity(4);
        mWorld.addChild(light1);
    }

    public void paint(Graphics g) {
        try {
            mGraphics3D.bindTarget(g);
            mGraphics3D.render(mWorld);
            mGraphics3D.releaseTarget();
        } catch (Exception ex) {}
        
        for(byte i = 0; i < colorButton.length; i++) {
            colorButton[i].paint(g);
        }
    }
    
    public void pointerPressed(int x, int y) {
        for(byte i = 0; i < colorButton.length; i++) {
            if(colorButton[i].contains(x, y)) {
                byte newColor = colorButton[i].getColorId();
                if(newColor != sprayColor) spray(newColor);
                break;
            }
        }
    }

    public void update() {
        mgBike.postRotate(6, 0, 1, 0);
    }
    
    private void spray(byte colorId) {
        sprayColor = colorId;
        Image2D img2D = new Image2D(Image2D.RGB, ImageHelper.loadImage("/models/bike"+sprayColor+".png"));
        Texture2D tex2D = new Texture2D(img2D);
        Appearance mAppearance = new Appearance();
        mAppearance.setTexture(0, tex2D);
        mBike.setAppearance(0, mAppearance);
        parent.setTempSprayColor(sprayColor);
    }
    
    public void dispose() {
        mGraphics3D = null;
        mWorld = null;
        mgBike = null;
    }
}
