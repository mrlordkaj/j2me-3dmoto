/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Vector;
import javax.microedition.m3g.Group;
import javax.microedition.m3g.World;
import util.CarPosition;
import util.MathHelper;

/**
 *
 * @author Thinh
 */
public class Level {
    public static final byte BIKE_MAX_SPEED = 100;
    
    private byte currentLevel;
    private byte numCarPerSegment;
    private short segmentLength, segmentTrim;
    private byte carTurnSpeed;
    private int carTurnChance; //turn
    private byte bikeMinSpeed;
    private byte carSpeed;
    
    private Play parent;
    private World mWorld;
    private Vector carList;
    private Group[] mgCar = new Group[2];
    private float[] mgCarZ = new float[2];
    private float stepZ;
    
    public float getBikeMinSpeed() { return bikeMinSpeed; }
    public byte getCarTurnSpeed() { return carTurnSpeed; }
    public boolean wantTurn() { return MathHelper.randomChance(carTurnChance); }
    
    public Level(World _mWorld, Play _parent) {
        mWorld = _mWorld;
        parent = _parent;
        
        carList = parent.getCarList();
        
        currentLevel = 1;
        
        numCarPerSegment = 1; //càng lớn càng khó
        segmentLength = 4500; //càng lớn càng thưa
        carTurnSpeed = 8; //càng lớn càng khó
        carTurnChance = 0; //càng lớn càng khó, lớn nhất là 5
        bikeMinSpeed = 70; //càng lớn càng khó
        carSpeed = 50; //càng nhỏ càng khó
        
        CarPosition.carSegment = (short)(segmentLength/4);
        segmentTrim = (short)(segmentLength/8);
        
        mgCar[0] = new Group();
        mgCarZ[0] = 0;
        mgCar[0].setTranslation(0, 0, mgCarZ[0]);
        mWorld.addChild(mgCar[0]);
        mgCar[1] = new Group();
        mgCarZ[1] = -segmentLength;
        mgCar[1].setTranslation(0, 0, mgCarZ[1]);
        mWorld.addChild(mgCar[1]);
    }
    
    public boolean levelUp(byte level) {
        if(level > 10 || level < 2) return false;
        if(level <= currentLevel) return false;
        
        currentLevel = level;

        switch(currentLevel) {
            case 2:
                numCarPerSegment = 2;
                segmentLength = 5000;
                carTurnSpeed = 9;
                carTurnChance = 30;
                bikeMinSpeed = 72;
                carSpeed = 48;
                break;

            case 3:
                numCarPerSegment = 2;
                segmentLength = 5500;
                carTurnSpeed = 10;
                carTurnChance = 40;
                bikeMinSpeed = 74;
                carSpeed = 46;
                break;

            case 4:
                numCarPerSegment = 2;
                segmentLength = 6000;
                carTurnSpeed = 11;
                carTurnChance = 50;
                bikeMinSpeed = 76;
                carSpeed = 44;
                break;

            case 5:
                numCarPerSegment = 3;
                segmentLength = 6500;
                carTurnSpeed = 12;
                carTurnChance = 50;
                bikeMinSpeed = 78;
                carSpeed = 42;
                break;

            case 6:
                numCarPerSegment = 3;
                segmentLength = 7000;
                carTurnSpeed = 14;
                carTurnChance = 60;
                bikeMinSpeed = 80;
                carSpeed = 40;
                break;

            case 7:
                numCarPerSegment = 3;
                segmentLength = 7500;
                carTurnSpeed = 15;
                carTurnChance = 60;
                bikeMinSpeed = 82;
                carSpeed = 38;
                break;

            case 8:
                numCarPerSegment = 4;
                segmentLength = 8000;
                carTurnSpeed = 16;
                carTurnChance = 60;
                bikeMinSpeed = 84;
                carSpeed = 36;
                break;

            case 9:
                numCarPerSegment = 4;
                segmentLength = 8500;
                carTurnSpeed = 17;
                carTurnChance = 60;
                bikeMinSpeed = 86;
                carSpeed = 34;
                break;

            case 10:
                numCarPerSegment = 4;
                segmentLength = 9000;
                carTurnSpeed = 18;
                carTurnChance = 60;
                bikeMinSpeed = 88;
                carSpeed = 32;
                break;
        }
        
        CarPosition.carSegment = (short)(segmentLength/3);
        segmentTrim = (short)(segmentLength/10);

        return true;
    }
    
    public void updateBikeSpeed(float bikeSpeed) {
        stepZ = (bikeSpeed-carSpeed)*Play.VELOCITY_RATE;
    }
    
    public void update() {
        //di chuyển các ô tô
        int numCar = carList.size();
        for(int i = numCar - 1; i >= 0; i--) {
            ((Car)carList.elementAt(i)).update(stepZ);
        }
        
        //di chuyển nhóm các ô tô
        for(byte i = 0; i < 2; i++) {
            mgCarZ[i] += stepZ;
            if(mgCarZ[i] > segmentLength) {
                mgCarZ[i] -= 2*segmentLength;
                generateNewCars(i);
            }
            mgCar[i].setTranslation(0, 0, mgCarZ[i]);
        }
    }
    
    public void updateDie() {
        //di chuyển các ô tô
        int numCar = carList.size();
        for(int i = numCar - 1; i >= 0; i--) {
            ((Car)carList.elementAt(i)).updateDie();
        }
        
        //di chuyển nhóm các ô tô
        for(byte i = 0; i < 2; i++) {
            mgCarZ[i] -= carSpeed*Play.VELOCITY_RATE;
            mgCar[i].setTranslation(0, 0, mgCarZ[i]);
        }
    }
    
    private void generateNewCars(byte segmentId) {
        //chuẩn bị vị trí
        Vector car = new Vector();
        while(car.size() < numCarPerSegment) {
            int numCar = car.size();
            byte lane = (byte)MathHelper.rand(Car.LANE_LEFT, Car.LANE_RIGHT);
            int position = -MathHelper.rand(segmentTrim, segmentLength-segmentTrim);
            int checked = 0;
            for(int i = 0; i < numCar; i++) {
                if(((CarPosition)car.elementAt(i)).collideWith(lane, position)) break;
                else checked++;
            }
            if(checked == numCar) {
                CarPosition newCarPosition = new CarPosition(lane, position);
                car.addElement(newCarPosition);
                int absolutePosition = position+(int)mgCarZ[segmentId];
                Car newCar = new Car(lane, position, absolutePosition, mgCar[segmentId], parent);
                carList.addElement(newCar);
            }
        }
    }
}
