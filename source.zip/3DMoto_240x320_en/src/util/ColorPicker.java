/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import javax.microedition.lcdui.Graphics;

/**
 *
 * @author Thinh
 */
public class ColorPicker {
    public static final byte COLOR_GRAY = 0;
    public static final byte COLOR_BLUE = 1;
    public static final byte COLOR_GREEN = 2;
    public static final byte COLOR_ORANGE = 3;
    public static final byte COLOR_PINK = 4;
    public static final byte COLOR_RED = 5;
    private byte colorId;
    private int color;
    
    private int x, y, width = 40, height = 40;
    
    public byte getColorId() { return colorId; }
    
    public ColorPicker(int colorId, int x, int y) {
        this.colorId = (byte)colorId;
        this.x = x;
        this.y = y;
        
        switch(this.colorId) {
            case COLOR_GRAY:
                color = 0x727273;
                break;
                
            case COLOR_BLUE:
                color = 0x3663ca;
                break;
                
            case COLOR_GREEN:
                color = 0x069006;
                break;
                
            case COLOR_ORANGE:
                color = 0xf65700;
                break;
                
            case COLOR_PINK:
                color = 0xbb31b3;
                break;
                
            case COLOR_RED:
                color = 0xc10000;
                break;
        }
    }
    
    public void paint(Graphics g) {
        g.setColor(color);
        g.fillRect(x, y, width, height);
        g.setColor(0xffffff);
        g.drawRect(x, y, width, height);
        g.drawRect(x+1, y+1, width-2, height-2);
    }
    
    public boolean contains(int x, int y) {
        if(x > this.x && x < this.x + width && y > this.y && y < this.y + height) return true;
        return false;
    }
}
