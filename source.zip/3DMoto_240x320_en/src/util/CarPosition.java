/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Thinh
 */
public class CarPosition {
    public static short carSegment;
    
    private int lane, position;
    
    public int getLane() { return lane; }
    public int getPosition() { return position; }
    
    public CarPosition(int lane, int position) {
        this.lane = lane;
        this.position = position;
    }
    
    public boolean collideWith(int targetLane, int targetPosition) {
        if(targetLane != lane) return false;
        
        if(targetPosition > position+carSegment || targetPosition < position-carSegment) return false;
        
        return true;
    }
    
//    public boolean checkAccident(int targetLane, int targetPosition) {
//        if(targetLane != lane) return false;
//        
//        if(targetPosition > position+800 || targetPosition < position-800) return false;
//        
//        return true;
//    }
}
