/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Thinh
 */
public class Rectangle {
    private float x, y, width, height;
    
    public float getX() { return x; }
    public float getY() { return y; }
    public float getWidth() { return width; }
    public float getHeight() { return height; }
    
    public Rectangle() {
        x = 0.f;
        y = 0.f;
        width = 0.f;
        height = 0.f;
    }
    
    public Rectangle(float _x, float _y, float _width, float _height) {
        x = _x;
        y = _y;
        width = _width;
        height = _height;
    }
    
    public void transform(float tx, float ty) {
        x += tx;
        y += ty;
    }
    
    public boolean collisionWith(Rectangle target) {
        boolean outsideBottom = y + height < target.getY();
        boolean outsideTop = y > target.getY() + target.getHeight();
        boolean outsideLeft = x > target.getX() + target.getWidth();
        boolean outsideRight = x + width < target.getX();
        return !(outsideBottom || outsideTop || outsideLeft || outsideRight);
    }
    
    public static boolean collision(Rectangle rect1, Rectangle rect2) {
        boolean outsideBottom = rect1.getY() + rect1.getHeight() < rect2.getY();
        boolean outsideTop = rect1.getY() > rect2.getY() + rect2.getHeight();
        boolean outsideLeft = rect1.getX() > rect2.getX() + rect2.getWidth();
        boolean outsideRight = rect1.getX() + rect1.getWidth() < rect2.getX();
        return !(outsideBottom || outsideTop || outsideLeft || outsideRight);
    }
}
