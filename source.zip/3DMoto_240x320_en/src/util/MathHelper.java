/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.util.Random;

/**
 *
 * @author Thinh
 */
public class MathHelper {
    public static final Random rand = new Random();
    
    public static boolean randomChance(int percent) {
        if(rand.nextInt(100) < percent) return true;
        else return false;
    }
    
    public static boolean randomChance(float percent) {
        if(percent == 0) return false;
        
        int maxValue = 100;
        float threshold = 1;
        while(percent < threshold) {
            maxValue *= 10;
            threshold /= 10;
        }
        percent *= maxValue/100;
        if(rand.nextInt(maxValue) < percent) return true;
        else return false;
    }
    
    public static int rand(int min, int max) {
        return rand.nextInt(max - min + 1) + min;
    }
}
