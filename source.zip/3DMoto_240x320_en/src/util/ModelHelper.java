/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.IOException;
import javax.microedition.m3g.Loader;
import javax.microedition.m3g.Mesh;
import javax.microedition.m3g.Node;
import javax.microedition.m3g.Object3D;
import javax.microedition.m3g.Texture2D;
import javax.microedition.m3g.World;

/**
 *
 * @author Thinh
 */
public class ModelHelper {
    
    public static Mesh loadModel(String fileName) {
        try {
            Object3D[] file = Loader.load(fileName);
            if(file[0] instanceof Mesh) {
                Mesh model = (Mesh)file[0];
                model.setTranslation(0, 0, 0);
                return model;
            }
            throw new RuntimeException("Resource " + fileName + " is not a valid type!");
        } catch (IOException ex) {
            throw new RuntimeException("Can't load resource file: " + fileName + " (" + ex.getMessage() + ")");
        }
    }
    
    public static Texture2D loadTexture(String fileName) {
        try {
            Object3D[] file = Loader.load(fileName);
            if(file[0] instanceof Texture2D) {
                Texture2D texture = (Texture2D)file[0];
                return texture;
            }
            throw new RuntimeException("Resource " + fileName + " is not a valid type!");
        } catch (IOException ex) {
            throw new RuntimeException("Can't load resource file: " + fileName + " (" + ex.getMessage() + ")");
        }
    }
    
    public static World loadWorld(String fileName) {
        try {
            Object3D[] allNodes = Loader.load(fileName);
            for(int i = 0, j = 0; i < allNodes.length; i++) {
                if(allNodes[i] instanceof World) {
                    return (World)allNodes[i];
                }
            }
            throw new RuntimeException("Can't find world in resource file: " + fileName);
        } catch (IOException ex) {
            throw new RuntimeException("Can't load resource file: " + fileName + " (" + ex.getMessage() + ")");
        }
    }
    
    public static Node extractNode(int id, World myWorld) {
        Node node = myWorld.getChild(id);
        node.setTranslation(0, 0, 0);
        return (Node)node.duplicate();
    }
}
