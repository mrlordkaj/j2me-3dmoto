/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

/**
 *
 * @author Thinh
 */
public class StringHelper {
    public static String numberToString(int number, int limit) {
        StringBuffer rs = new StringBuffer(Integer.toString(number));
        while(rs.length() > limit) rs.deleteCharAt(0);
        while(rs.length() < limit) rs.insert(0, "0");
        return rs.toString();
    }
}
