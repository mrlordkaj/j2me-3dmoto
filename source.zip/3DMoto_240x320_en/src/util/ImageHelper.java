/*
 * Copyright © 2012 Nokia Corporation. All rights reserved.
 * Nokia and Nokia Connecting People are registered trademarks of Nokia Corporation.
 * Oracle and Java are trademarks or registered trademarks of Oracle and/or its
 * affiliates. Other product and company names mentioned herein may be trademarks
 * or trade names of their respective owners.
 * See LICENSE.TXT for license information.
 */
package util;

import java.io.IOException;
import java.io.InputStream;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.Sprite;

public class ImageHelper {
    private static final Sprite digitalNumber = new Sprite(loadImage("/images/digitalnumber.png"), 11, 18);
    /**
     * Loads an image from resources
     * @param path Path of the image file
     * @return Loaded image
     * @throws RuntimeException
     */
    public static Image loadImage(String path) throws RuntimeException {
        Image image = null;

        try {
            InputStream in = Image.class.getResourceAsStream(path);
            image = Image.createImage(in);
        } catch (IOException ioe) {
            throw new RuntimeException("Failed to load image: " + path + " " + ioe.getMessage());
        }

        return image;
    }
    
    public static void drawDigitalNumber(String number, int x, int y, Graphics g) {
        for(int i = 0; i < number.length(); i++) {
            int numberId = number.charAt(i) - 48;
            if(i >= number.length() - 2) numberId += 10;
            digitalNumber.setPosition(x+i*11, y);
            digitalNumber.setFrame(numberId);
            digitalNumber.paint(g);
        }
    }
    
    public static void drawClockwise(int x, int y, float angle, Graphics g) {
        int x2 = x + (int)(30 * Math.cos(angle*3.141592653589f/180));
        int y2 = y - (int)(30 * Math.sin(angle*3.141592653589f/180));
        g.drawLine(x, y, x2, y2);
    }
}
