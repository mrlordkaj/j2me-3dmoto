/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.m3g.Appearance;
import javax.microedition.m3g.Group;
import javax.microedition.m3g.Image2D;
import javax.microedition.m3g.Mesh;
import javax.microedition.m3g.Texture2D;
import javax.microedition.m3g.World;
import util.ImageHelper;
import util.MathHelper;
import util.ModelHelper;

/**
 *
 * @author Thinh
 */
public class Road {
    public static final byte ROAD_TYPE_TUNNEL = 0;
    public static final byte ROAD_TYPE_BRIDGE = 1;
    public static final byte ROAD_TYPE_SUBURB = 2;
    public static final byte ROAD_TYPE_MOUNTAIN = 3;
    
    public static final int ROAD_SEGMENT_LENGTH = 3440;
    private static final byte DISPLAY_SEGMENT = 4;
    private static final byte TUNNEL_NUM_SEGMENT = 6;
    private static final byte ROAD_NUM_SEGMENT = 50;
    
    private Group gmBridgeRoadSegment, gmTunnelRoadSegment, gmSubUrbRoadSegment, gmMountainRoadSegment;
    private Mesh tunnelGateModel;
    private int segmentReplaced, segmentLeft;
    private byte roadType = ROAD_TYPE_BRIDGE;
    
    private Group[] segment;
    private float[] segmentZ;
    private float step;
    
    private World mWorld;
    private Play parent;
    
    public Road(World _mWorld, Play _parent) {
        mWorld = _mWorld;
        parent = _parent;
        
        prepareResource();
    }
    
    public void start() {
        //reset
        if(segment != null) {
            for(int i = 0; i < DISPLAY_SEGMENT; i++) {
                mWorld.removeChild(segment[i]);
            }
        }
        if(roadType == ROAD_TYPE_TUNNEL) mWorld.removeChild(tunnelGateModel);
        segmentReplaced = 0;
        segmentLeft = ROAD_NUM_SEGMENT;
        roadType = ROAD_TYPE_BRIDGE;
        
        //chuẩn bị sẵn các đoạn đường
        segment = new Group[DISPLAY_SEGMENT];
        segmentZ = new float[DISPLAY_SEGMENT];
        while(segmentReplaced < DISPLAY_SEGMENT) {
            segment[segmentReplaced] = (Group)gmBridgeRoadSegment.duplicate();
            segmentZ[segmentReplaced] = -segmentReplaced*ROAD_SEGMENT_LENGTH;
            segment[segmentReplaced].setTranslation(0, 0, segmentZ[segmentReplaced]);
            mWorld.addChild(segment[segmentReplaced]);
            segmentReplaced++;
        }
    }
    
    private void prepareResource() {
        //chuẩn bị nhóm đường cầu
        gmBridgeRoadSegment = new Group();
        World roadRes = ModelHelper.loadWorld("/models/roads.res");
        Mesh bridgeRoadModel = (Mesh)ModelHelper.extractNode(0, roadRes);
        gmBridgeRoadSegment.addChild(bridgeRoadModel);
        Mesh rightStreetLight = ModelHelper.loadModel("/models/streetlight.res");
        rightStreetLight.postRotate(-90, 0, 1, 0);
        rightStreetLight.translate(560, 0, 0);
        rightStreetLight.setScale(0.8f, 0.8f, 0.8f);
        Image2D img2D = new Image2D(Image2D.RGB, ImageHelper.loadImage("/models/YZF-R1-512-new-grey.png"));
        Texture2D tex2D = new Texture2D(img2D);
        Appearance mAppearance = new Appearance();
        mAppearance.setTexture(0, tex2D);
        rightStreetLight.setAppearance(0, mAppearance);
        gmBridgeRoadSegment.addChild(rightStreetLight);
        Mesh leftStreetLight = (Mesh)rightStreetLight.duplicate();
        leftStreetLight.postRotate(180, 0, 1, 0);
        leftStreetLight.translate(-1120, 0, 0);
        gmBridgeRoadSegment.addChild(leftStreetLight);
        
        //chuẩn bị nhóm đường ngoại ô
        gmSubUrbRoadSegment = new Group();
        Mesh subUrbRoadModel = (Mesh)ModelHelper.extractNode(1, roadRes);
        gmSubUrbRoadSegment.addChild(subUrbRoadModel);
        Mesh rightPalmModel = ModelHelper.loadModel("/models/palm.res");
        mAppearance.setTexture(0, tex2D);
        rightStreetLight.setAppearance(0, mAppearance);
        rightPalmModel.setAppearance(0, mAppearance);
        rightPalmModel.setTranslation(700, 0, 0);
        rightPalmModel.setScale(0.8f, 0.8f, 0.8f);
        gmSubUrbRoadSegment.addChild(rightPalmModel);
        Mesh leftPalmModel = (Mesh)rightPalmModel.duplicate();
        leftPalmModel.translate(-1300, 0, 0);
        gmSubUrbRoadSegment.addChild(leftPalmModel);
        
        //chuẩn bị đường hẻm núi
        gmMountainRoadSegment = new Group();
        gmMountainRoadSegment.addChild((Mesh)subUrbRoadModel.duplicate());
        Mesh mountainModel = ModelHelper.loadModel("/models/mountain.res");
        mountainModel.setScale(1.2f, 1, 0.5f);
        mountainModel.setOrientation(90, 0, 1, 0);
        mountainModel.translate(-740, 0, 0);
        gmMountainRoadSegment.addChild(mountainModel);
        Mesh pineModel = ModelHelper.loadModel("/models/pine.res");
        pineModel.setOrientation(-90, 0, 1, 0);
        pineModel.translate(1280, 40, 0);
        pineModel.setScale(0.8f, 0.8f, 0.8f);
        gmMountainRoadSegment.addChild(pineModel);
        
        //chuẩn bị nhóm đường hầm
        gmTunnelRoadSegment = new Group();
        Mesh tunnelModel = (Mesh)ModelHelper.extractNode(2, roadRes);
        tunnelModel.setPickingEnable(false);
        gmTunnelRoadSegment.addChild(tunnelModel);
        Mesh tunnelRoadModel = (Mesh)ModelHelper.extractNode(3, roadRes);
        tunnelRoadModel.setPickingEnable(false);
        gmTunnelRoadSegment.addChild(tunnelRoadModel);
        //cửa hầm
        tunnelGateModel = ModelHelper.loadModel("/models/tunnelgate.res");
        tunnelGateModel.setScale(0.46f, 0.56f, 0.56f);
        
        roadRes = null;
    }
    
    public void updateBikeVelocity() {
        step = parent.getBike().getSpeed()*Play.VELOCITY_RATE;
    }
    
    public void update() {
        //if(step == 0) System.out.println("WARNING: Bike's velocity is not set (in Road).");
        
        for(int i = 0; i < DISPLAY_SEGMENT; i++) {
            segmentZ[i] += step;
            if(segmentZ[i] > 2400) {
                if(segmentReplaced < DISPLAY_SEGMENT) {
                    mWorld.removeChild(segment[i]);
                    switch(roadType) {
                        case ROAD_TYPE_BRIDGE:
                            segment[i] = (Group)gmBridgeRoadSegment.duplicate();
                            break;
                            
                        case ROAD_TYPE_SUBURB:
                            segment[i] = (Group)gmSubUrbRoadSegment.duplicate();
                            Mesh rightPalm = (Mesh)segment[i].getChild(1);
                            rightPalm.postRotate(MathHelper.rand(-20, 30), 0, 1, 0);
                            rightPalm.translate(0, 0, MathHelper.rand(-1300, 1300));
                            Mesh leftPalm = (Mesh)segment[i].getChild(2);
                            leftPalm.postRotate(MathHelper.rand(-20, 30), 0, 1, 0);
                            leftPalm.translate(0, 0, MathHelper.rand(-1300, 1300));
                            break;
                            
                        case ROAD_TYPE_MOUNTAIN:
                            segment[i] = (Group)gmMountainRoadSegment.duplicate();
                            break;
                            
                        case ROAD_TYPE_TUNNEL:
                            segment[i] = (Group)gmTunnelRoadSegment.duplicate();
                            if(segmentReplaced == 1) parent.cameraDown();
                            if(segmentReplaced == 3) mWorld.removeChild(tunnelGateModel);
                            break;
                    }
                    mWorld.addChild(segment[i]);
                    segmentReplaced++;
                } else if(segmentReplaced == 4 && roadType != ROAD_TYPE_TUNNEL) {
                    parent.cameraUp();
                }
                segmentZ[i] -= DISPLAY_SEGMENT*ROAD_SEGMENT_LENGTH;
                
                if(--segmentLeft == 0) { //chuyển đổi loại đường
                    if(roadType != ROAD_TYPE_TUNNEL) { //từ đường sang hầm
                        roadType = ROAD_TYPE_TUNNEL;
                        tunnelGateModel.setTranslation(8, -890, -DISPLAY_SEGMENT*ROAD_SEGMENT_LENGTH+700);
                        mWorld.addChild(tunnelGateModel);
                        segmentReplaced = 0;
                        segmentLeft = TUNNEL_NUM_SEGMENT;
                    } else { //từ hầm sang đường
                        roadType = (byte)MathHelper.rand(1, 3);
                        parent.setBackground(roadType);
                        segmentReplaced = 0;
                        segmentLeft = ROAD_NUM_SEGMENT;
                    }
                }
            }
            segment[i].setTranslation(0, 0, segmentZ[i]);
        }
        
        if(roadType == ROAD_TYPE_TUNNEL) tunnelGateModel.translate(0, 0, step);
    }
    
    public void updateDie() {
        if(step > 0) step -= parent.getBike().getSpeed()*0.1f;
        else step = 0;
        for(int i = 0; i < DISPLAY_SEGMENT; i++) {
            segmentZ[i] += step;
            if(segmentZ[i] > 2400) {
                if(segmentReplaced < DISPLAY_SEGMENT) {
                    mWorld.removeChild(segment[i]);
                    switch(roadType) {
                        case ROAD_TYPE_BRIDGE:
                            segment[i] = (Group)gmBridgeRoadSegment.duplicate();
                            break;
                            
                        case ROAD_TYPE_SUBURB:
                            segment[i] = (Group)gmSubUrbRoadSegment.duplicate();
                            Mesh rightPalm = (Mesh)segment[i].getChild(1);
                            rightPalm.postRotate(MathHelper.rand(-20, 30), 0, 1, 0);
                            rightPalm.translate(0, 0, MathHelper.rand(-1300, 1300));
                            Mesh leftPalm = (Mesh)segment[i].getChild(2);
                            leftPalm.postRotate(MathHelper.rand(-20, 30), 0, 1, 0);
                            leftPalm.translate(0, 0, MathHelper.rand(-1300, 1300));
                            break;
                            
                        case ROAD_TYPE_MOUNTAIN:
                            segment[i] = (Group)gmMountainRoadSegment.duplicate();
                            break;
                            
                        case ROAD_TYPE_TUNNEL:
                            segment[i] = (Group)gmTunnelRoadSegment.duplicate();
                            if(segmentReplaced == 1) parent.cameraDown();
                            if(segmentReplaced == 3) mWorld.removeChild(tunnelGateModel);
                            break;
                    }
                    mWorld.addChild(segment[i]);
                    segmentReplaced++;
                }
                segmentZ[i] -= DISPLAY_SEGMENT*ROAD_SEGMENT_LENGTH;
            }
            segment[i].setTranslation(0, 0, segmentZ[i]);
        }
        
        if(roadType == ROAD_TYPE_TUNNEL) tunnelGateModel.translate(0, 0, step);
    }
}
