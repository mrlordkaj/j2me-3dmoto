/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Vector;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.m3g.*;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.sensor.Data;
import javax.microedition.sensor.DataListener;
import javax.microedition.sensor.SensorConnection;
import util.GraphicButton;
import util.ImageHelper;
import util.ModelHelper;
import util.StringHelper;

/**
 *
 * @author Thinh
 */
class Play extends GamePage implements DataListener, CommandListener {
    private static final byte COMMAND_NONE = 0;
    private static final byte COMMAND_MENU = 1;
    private static final byte COMMAND_RESUME = 2;
    private static final byte COMMAND_RESTART = 3;
    private static final short CONTROLLER_CENTER = 172;
    public static final int STATE_NONE = 0;
    public static final int STATE_READY = 1;
    public static final int STATE_RUN = 2;
    public static final int STATE_DIE = 3;
    public static final int STATE_PAUSE = 4;
    public static final int STATE_END = 5;
    public static final int CAMERA_STAY = 0;
    public static final int CAMERA_UP = 1;
    public static final int CAMERA_DOWN = 2;
    public static final byte VELOCITY_RATE = 4;
    
    public static final Font BOLD_LARGE = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_LARGE);
    public static final Font BOLD_MEDIUM = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
    
    private Image readyImg, goImg, meterImg, speedometerImg, controllerImg, speedLedImg, dangerImg, maskPauseImg, maskGameOverImg, newRecordImg, newRecordSmallImg;
    private Graphics meterImgGraphics;
    private Image[] btnMenuImg, backgroundImg;
    
    private short controllerX;
    private boolean returnControl = false;
    
    private Graphics3D mGraphics3D = Graphics3D.getInstance();
    private World mWorld;
    
    private Mesh[] carModel;
    
    private Background mBackground;
    private int bgY;
    
    private Camera mCamera;
    private int cameraTimeline = 0;
    private int cameraAction = CAMERA_STAY;
    
    private Vector carList;
    private Bike bike;
    private Road road;
    private float meter10Reach, meter100PerTick;
    
    private float speedometerAngle, minSpeedometerAngle;
    
    private Level level;
    
    private int state = STATE_NONE, prevState;
    private int msgReadyTimeline, msgReadyX;
    private boolean displayWarning, isSpeedUp = false;
    
    private int record, score = 0;
    private boolean isNewRecord = false, isBonus = false;
    
    private boolean isTouchOnly;
    
    private Main parent;
    private GraphicButton[] btnMenu;
    private byte activeCommand = COMMAND_NONE;
    
    public Mesh getCarModel(int id) { return (Mesh)carModel[id].duplicate(); }
    public int getMeter10Reach() { return (int)meter10Reach; }
    public Vector getCarList() { return carList; }
    public void flashWarning() { displayWarning = !displayWarning; }
    public void disableWarning() { displayWarning = false; }
    public Bike getBike() { return bike; }
    public Road getRoad() { return road; }
    public Level getLevel() { return level; }
    public void setBonus() { isBonus = true; }
    
    public Play(Main _parent) {
        super();
        parent = _parent;
        
        isTouchOnly = parent.isTouchOnly;
        
        schedule = 100;
        new Thread(this).start();
        
        prepareResource();
        
        startGame();
        
        addCommand(new Command("Back", Command.BACK, 1));
        setCommandListener(this);
    }
    
    private void prepareResource() {
        mWorld = new World();
        
        //chuẩn bị hình ảnh
        readyImg = ImageHelper.loadImage("/images/msgready.png");
        goImg = ImageHelper.loadImage("/images/msggo.png");
        dangerImg = ImageHelper.loadImage("/images/msgdanger.png");
        maskPauseImg = ImageHelper.loadImage("/images/mskpause.png");
        maskGameOverImg = ImageHelper.loadImage("/images/mskgameover.png");
        newRecordImg = ImageHelper.loadImage("/images/newrecord.png");
        newRecordSmallImg = ImageHelper.loadImage("/images/newrecord_small.png");
        btnMenuImg = new Image[] {
            ImageHelper.loadImage("/images/btnmenu.png"),
            ImageHelper.loadImage("/images/btnrestart.png"),
            ImageHelper.loadImage("/images/btnresume.png")
        };
        
        backgroundImg = new Image[3];
        for(int i = 0; i < 3; i++) {
            backgroundImg[i] = ImageHelper.loadImage("/images/bg" + i + ".png");
        }
        
        if(isTouchOnly) {
            speedometerImg = ImageHelper.loadImage("/images/speedometerb.png");
            controllerImg = ImageHelper.loadImage("/images/controller.png");
            speedLedImg = ImageHelper.loadImage("/images/speedledb.png");
        } else {
            speedometerImg = ImageHelper.loadImage("/images/speedometera.png");
            meterImg = Image.createImage(55, 18);
            meterImgGraphics = meterImg.getGraphics();
            speedLedImg = ImageHelper.loadImage("/images/speedleda.png");
        }
        
        //khởi tạo nguồn sáng
        Light light1 = new Light();
        light1.setTranslation(0, 400, 0);
        light1.setColor(0xffffff);
        light1.setMode(Light.AMBIENT);
        light1.setIntensity(4);
        mWorld.addChild(light1);
        
        //khởi tạo camera
        mCamera = new Camera();
        mCamera.setPerspective(
            60,
            (float)Main.SCREENSIZE_WIDTH / (float)Main.SCREENSIZE_HEIGHT,
            100,
            9000
        );
        mWorld.addChild(mCamera);
        mWorld.setActiveCamera(mCamera);
        
        //chuẩn bị xe
        bike = new Bike(parent.sprayColor, mWorld, this);
        
        //hình nền
        mBackground = new Background();
        mWorld.setBackground(mBackground);
        
        //chuẩn bị mẫu xe ô tô
        carModel = new Mesh[Car.NUMBER_TYPE];
        carModel[Car.TYPE_BUS] = ModelHelper.loadModel("/models/bus.res");
        carModel[Car.TYPE_BUS].setOrientation(-90, 1, 0, 0);
        carModel[Car.TYPE_BUS].setScale(1.2f, 1.2f, 1.2f);
        carModel[Car.TYPE_TRUCK] = ModelHelper.loadModel("/models/truck.res");
        carModel[Car.TYPE_TRUCK].setOrientation(-90, 1, 0, 0);
        carModel[Car.TYPE_TRUCK].setScale(1.2f, 1.5f, 1.2f);
        carModel[Car.TYPE_AUTO] = ModelHelper.loadModel("/models/auto.res");
        carModel[Car.TYPE_AUTO].setOrientation(-90, 1, 0, 0);
        //carModel[Car.TYPE_AUTO].setScale(1, 1, 1);
        
        road = new Road(mWorld, this);
        
        try {
            RecordStore rs = RecordStore.openRecordStore(Main.RMS_SCORE, true);
            record = Integer.parseInt(new String(rs.getRecord(1)));
            rs.closeRecordStore();
        } catch (RecordStoreException ex) {
            record = 0;
        }
        
        //bắt đầu trò chơi
        isLoading = false;
    }
    
    public void setBackground(int backgroundId) {
        Image2D imgBg = new Image2D(Image2D.RGB, backgroundImg[--backgroundId]);
        mBackground.setImage(imgBg);
        mBackground.setCrop(0, bgY, Main.SCREENSIZE_WIDTH, Main.SCREENSIZE_HEIGHT);
    }
    
    private void startGame() {
        setBackground(Road.ROAD_TYPE_BRIDGE);
        bgY = 80; //for 240x320
        //bgY = 100; //for 240x400
        mBackground.setCrop(0, bgY, Main.SCREENSIZE_WIDTH, Main.SCREENSIZE_HEIGHT);
        
        isSpeedUp = false;
        score = 0;
        isNewRecord = false;
        displayWarning = false;
        
        cameraTimeline = 0;
        cameraAction = CAMERA_STAY;
        mCamera.setOrientation(-39, 1, 0, 0);
        mCamera.setTranslation(0, 800, -70);
        
        msgReadyTimeline = 0;
        msgReadyX = -80;
        
        if(!isTouchOnly) {
            meterImgGraphics.setColor(0x000000);
            meterImgGraphics.fillRect(0, 0, 55, 18);
            ImageHelper.drawDigitalNumber("00000", 0, 0, meterImgGraphics);
        }
        
        bike.reset();
        meter10Reach = 0;
        meter100PerTick = 0;
        
        road.start();
        
        if(carList != null && !carList.isEmpty()) {
            for(int i = 0; i < carList.size(); i++) {
                Car carToRemove = (Car)carList.elementAt(i);
                carToRemove.dispose();
                carToRemove = null;
            }
        }
        carList = new Vector();
        
        level = new Level(mWorld, this);
        
        bike.setVelocity(level.getBikeMinSpeed());
        
        speedometerAngle = 222;
        minSpeedometerAngle = 222 - (bike.getSpeed()*2.64f);
        controllerX = CONTROLLER_CENTER;
        state = STATE_READY;
    }
    
    public void paint(Graphics g) {
        if(isLoading) return;
        
        try {
            mGraphics3D.bindTarget(g);
            mGraphics3D.render(mWorld);
            mGraphics3D.releaseTarget();
        } catch (Exception ex) {}
        
        g.drawImage(speedometerImg, 0, Main.SCREENSIZE_HEIGHT, Graphics.LEFT | Graphics.BOTTOM);
        
        //vẽ kim đồng hồ
        g.setColor(0xe00000);
        ImageHelper.drawClockwise(52, Main.SCREENSIZE_HEIGHT-32, speedometerAngle, g);
        
        //vạch bonus và điểm
        g.setFont(BOLD_LARGE);
        g.drawString("I I", Main.SCREENSIZE_WIDTH-4, 6, Graphics.TOP | Graphics.RIGHT);
        if(isBonus) g.setColor(0x00ffff);
        g.drawString(Integer.toString(score), 4, 6, Graphics.TOP | Graphics.LEFT);
        if(isNewRecord) g.drawImage(newRecordSmallImg, 0, 26, Graphics.LEFT | Graphics.TOP);
        
        //số km đi được
        if(isTouchOnly) {
            if(isSpeedUp) g.drawImage(speedLedImg, 53, Main.SCREENSIZE_HEIGHT-14, Graphics.HCENTER | Graphics.VCENTER);
            g.drawImage(controllerImg, controllerX, Main.SCREENSIZE_HEIGHT-18, Graphics.HCENTER | Graphics.BOTTOM);
        } else {
            if(isSpeedUp) g.drawImage(speedLedImg, 211, Main.SCREENSIZE_HEIGHT-25, Graphics.HCENTER | Graphics.VCENTER);
            g.drawImage(meterImg, 119, Main.SCREENSIZE_HEIGHT-44, Graphics.LEFT | Graphics.TOP);
        }
        
        switch(state) {
            case STATE_READY:
                if(msgReadyTimeline <= 30) {
                    g.drawImage(readyImg, msgReadyX, Main.SCREENSIZE_HEIGHT/2, Graphics.HCENTER | Graphics.BOTTOM);
                } else if(msgReadyTimeline <= 100) {
                    g.drawImage(goImg, msgReadyX, Main.SCREENSIZE_HEIGHT/2, Graphics.HCENTER | Graphics.BOTTOM);
                }
                break;
                
            case STATE_RUN:
                if(displayWarning) {
                    g.drawImage(dangerImg, Main.SCREENSIZE_WIDTH/2, Main.SCREENSIZE_HEIGHT/2, Graphics.HCENTER | Graphics.VCENTER);
                }
                break;
                
            case STATE_PAUSE:
                g.drawImage(maskPauseImg, 0, 0, Graphics.LEFT | Graphics.TOP);
                for(int i = 0; i < btnMenu.length; i++) {
                    btnMenu[i].paint(g);
                }
                break;
                
            case STATE_END:
                g.drawImage(maskGameOverImg, 0, 0, Graphics.LEFT | Graphics.TOP);
                g.setColor(0xffffff);
                g.setFont(BOLD_LARGE);
                g.drawString(Integer.toString(score), Main.SCREENSIZE_WIDTH/2, 115, Graphics.HCENTER | Graphics.BASELINE);
                g.drawString(Integer.toString(record), Main.SCREENSIZE_WIDTH/2, 165, Graphics.HCENTER | Graphics.BASELINE);
                if(isNewRecord) g.drawImage(newRecordImg, 10, 130, Graphics.LEFT | Graphics.TOP);
                for(int i = 0; i < btnMenu.length; i++) {
                    btnMenu[i].paint(g);
                }
                break;
        }
    }

    protected void update() {
        if(isLoading) return;
        
        switch(state) {
            case STATE_READY:
                updateReady();
                break;
                
            case STATE_RUN:
                updateRun();
                break;
                
            case STATE_DIE:
                updateDie();
                break;
        }
    }
    
    private void updateReady() {
        msgReadyTimeline++;
        
        if(msgReadyTimeline <= 38) {
            mCamera.translate(0, 0, 20);
            if(msgReadyTimeline <= 8) msgReadyX += 25;
            else if(msgReadyTimeline <= 22);
            else if(msgReadyTimeline <= 30) msgReadyX += 25;
            else if(msgReadyTimeline == 31) msgReadyX = -60;
            else msgReadyX += 25;
        } else if(msgReadyTimeline <= 52);
        else if(msgReadyTimeline <= 60) msgReadyX += 25;
        else {
            state = STATE_RUN;
        }
        
        if(speedometerAngle > minSpeedometerAngle) speedometerAngle -= 3.6f;
        else speedometerAngle = minSpeedometerAngle;
        
        //con đường dịch chuyển về phía sau
        road.update();
    }
    
    private void updateRun() {
        bike.updateRun();
        
        //tăng/giảm tốc
        if(isSpeedUp) bike.requestSpeedUp(Level.BIKE_MAX_SPEED);
        else bike.requestSlowDown(level.getBikeMinSpeed());
        
        //cập nhật vị trí và góc quay camera
        updateCamera();
        
        //tính quãng đường đi được
        int prevMeter = (int)meter10Reach;
        meter10Reach += meter100PerTick;
        if((int)meter10Reach > prevMeter) {
            if(isTouchOnly) {
                if(returnControl) {
                    touchDrive(CONTROLLER_CENTER);
                    returnControl = false;
                }
            } else {
                String strMeter = StringHelper.numberToString((int)meter10Reach, 5);
                meterImgGraphics.setColor(0x000000);
                meterImgGraphics.fillRect(0, 0, 55, 18);
                ImageHelper.drawDigitalNumber(strMeter, 0, 0, meterImgGraphics);
            }
            if(isBonus) score += 3;
            else score += 1;
            if(!isNewRecord && record > 0) {
                if(score > record) {
                    record = score;
                    isNewRecord = true;
                }
            }
        }
        
        //con đường dịch chuyển về phía sau
        road.update();
        level.update();
        
        if(level.levelUp((byte)(meter10Reach/100 + 1))) {
            System.out.println("Level up!");
            if(bike.getSpeed() < level.getBikeMinSpeed()) bike.setVelocity(level.getBikeMinSpeed());
        }
    }
    
    private void updateDie() {
        if(++msgReadyTimeline < 40) {
            updateCamera();
            bike.updateDie();
            road.updateDie();
            level.updateDie();
            if(speedometerAngle < 222) speedometerAngle += 16;
            else if(speedometerAngle > 222) speedometerAngle = 222;
        } else {
            gameOver();
        }
    }
    
    private void pause() {
        btnMenu = new GraphicButton[] {
            new GraphicButton(btnMenuImg[0], COMMAND_MENU, 38, 100, 72, 92),
            new GraphicButton(btnMenuImg[1], COMMAND_RESTART, 130, 100, 72, 92),
            new GraphicButton(btnMenuImg[2], COMMAND_RESUME, 84, 220, 72, 92)
        };
        state = STATE_PAUSE;
    }
    
    private void gameOver() {
        if(isNewRecord || record == 0) {
            isNewRecord = true;
            record = score;
            try {
                RecordStore rs = RecordStore.openRecordStore(Main.RMS_SCORE, false);
                byte[] writer = Integer.toString(record).getBytes();
                rs.setRecord(1, writer, 0, writer.length);
                rs.closeRecordStore();
            } catch (RecordStoreException ex) {
            }
        }
        btnMenu = new GraphicButton[] {
            new GraphicButton(btnMenuImg[0], COMMAND_MENU, 38, 215, 72, 92),
            new GraphicButton(btnMenuImg[1], COMMAND_RESTART, 130, 215, 72, 92)
        };
        state = STATE_END;
    }
    
    private void updateCamera() {
        switch(cameraAction) {
            case CAMERA_DOWN:
                cameraTimeline++;
                mCamera.postRotate(0.7f, 1, 0, 0);
                mCamera.translate(0, -24, 0.5f);
                bgY -= 4; //for 240x320
                //bgY -= 5; //for 240x400
                mBackground.setCrop(0, bgY, Main.SCREENSIZE_WIDTH, Main.SCREENSIZE_HEIGHT);
                if(cameraTimeline == 20) cameraAction = CAMERA_STAY;
                break;
                
            case CAMERA_UP:
                cameraTimeline--;
                mCamera.postRotate(-0.7f, 1, 0, 0);
                mCamera.translate(0, 24, -0.5f);
                bgY += 4; //for 240x320
                //bgY += 5; //for 240x400
                mBackground.setCrop(0, bgY, Main.SCREENSIZE_WIDTH, Main.SCREENSIZE_HEIGHT);
                if(cameraTimeline == 0) cameraAction = CAMERA_STAY;
                break;
        }
    }
    
    public void setDie() {
        state = STATE_DIE;
        msgReadyTimeline = 0;
    }
    
    public void removeCar(Car carToRemove) {
        carList.removeElement(carToRemove);
        carToRemove = null;
        if(isBonus) score += 8;
        else score += 5;
    }
    
    public void cameraUp() {
        if(cameraAction != CAMERA_STAY) return;
        
        if(cameraTimeline == 20) cameraAction = CAMERA_UP;
    }
    
    public void cameraDown() {
        if(cameraAction != CAMERA_STAY) return;
        
        if(cameraTimeline == 0) cameraAction = CAMERA_DOWN;
    }
    
    protected void pointerPressed(int x, int y) {
        if(isLoading) return;
        
        switch(state) {
            case STATE_RUN:
                if(x > Main.SCREENSIZE_WIDTH-40 && y < 60) {
                    prevState = state;
                    pause();
                } else {
                    if(isTouchOnly) {
                        if(y > Main.SCREENSIZE_HEIGHT-100) {
                            if(x > 100) touchDrive((short)x);
                            else isSpeedUp = !isSpeedUp;
                        }
                    }
                    else isSpeedUp = true;
                }
                break;
                
            case STATE_PAUSE:
            case STATE_END:
                for(int i = 0; i < btnMenu.length; i++) {
                    if(btnMenu[i].contains(x, y)) {
                        btnMenu[i].active = true;
                        activeCommand = btnMenu[i].getCommand();
                        return;
                    }
                }
                break;
        }
    }
    
    protected void pointerDragged(int x, int y) {
        if(isLoading) return;
        
        switch(state) {
            case STATE_RUN:
                if(isTouchOnly) {
                    if(x>100 && y>Main.SCREENSIZE_HEIGHT-100) touchDrive((short)x);
                }
                break;
                
            case STATE_PAUSE:
            case STATE_END:
                activeCommand = COMMAND_NONE;
                for(int i = 0; i < btnMenu.length; i++) {
                    btnMenu[i].active = false;
                    if(btnMenu[i].contains(x, y)) {
                        btnMenu[i].active = true;
                        activeCommand = btnMenu[i].getCommand();
                    }
                }
                break;
        }
    }
    
    protected void pointerReleased(int x, int y) {
        if(isLoading) return;
        
        switch(state) {
            case STATE_RUN:
                if(isTouchOnly) {
                    returnControl = true;
                } else {
                    isSpeedUp = false;
                    isBonus = false;
                }
                break;
            
            case STATE_PAUSE:
            case STATE_END:
                switch(activeCommand) {
                    case COMMAND_MENU:
                        parent.gotoMainMenu();
                        break;
                        
                    case COMMAND_RESUME:
                        state = prevState;
                        break;
                        
                    case COMMAND_RESTART:
                        startGame();
                        break;
                }
                for(int i = 0; i < btnMenu.length; i++) {
                    btnMenu[i].active = false;
                }
                activeCommand = COMMAND_NONE;
                break;
        }
    }
    
    protected void hideNotify() {
        if(state == STATE_READY || state == STATE_RUN || state == STATE_DIE) {
            prevState = state;
            pause();
        }
    }
    
    public void updateBikeVelocity() {
        float bikeSpeed = bike.getSpeed();
        meter100PerTick = (bikeSpeed * schedule) / 36000;
        speedometerAngle = 222 - (bikeSpeed*2.64f);
        road.updateBikeVelocity();
        level.updateBikeSpeed(bikeSpeed);
    }
    
    private void touchDrive(short x) {
        if(x < CONTROLLER_CENTER-60) x = CONTROLLER_CENTER-60;
        else if(x > CONTROLLER_CENTER+60) x = CONTROLLER_CENTER+60;
        controllerX = x;
        byte xData = (byte)((CONTROLLER_CENTER-x)*0.25f);
        bike.updateSkewAngle(xData);
        returnControl = false;
    }

    public void dataReceived(SensorConnection sensor, Data[] data, boolean isDataLost) {
        if(state != STATE_RUN) return;
        
        byte xData = (byte)(data[0].getDoubleValues()[0]*10);
        if(xData < -Bike.SKEWANGLE_MAX/2) xData = -Bike.SKEWANGLE_MAX/2;
        else if(xData > Bike.SKEWANGLE_MAX/2) xData = Bike.SKEWANGLE_MAX/2;
        bike.updateSkewAngle(xData);
        //for 240x320
        /*
        byte xData = (byte)(data[0].getDoubleValues()[0]*10/3);
        xData = (byte)(xData*3);
        if(xData < -Bike.SKEWANGLE_MAX/2) xData = -Bike.SKEWANGLE_MAX/2;
        else if(xData > Bike.SKEWANGLE_MAX/2) xData = Bike.SKEWANGLE_MAX/2;
        bike.updateSkewAngle(xData);
        */ //for 240x400
    }

    public void commandAction(Command c, Displayable d) {
        if(c.getCommandType() == Command.BACK) {
            if(state == STATE_READY || state == STATE_RUN || state == STATE_DIE) {
                prevState = state;
                pause();
            } else if(state == STATE_PAUSE || state == STATE_END) {
                parent.gotoMainMenu();
            }
        }
    }
}
