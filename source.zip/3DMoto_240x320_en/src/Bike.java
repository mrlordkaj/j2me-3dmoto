/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Vector;
import javax.microedition.m3g.Appearance;
import javax.microedition.m3g.Group;
import javax.microedition.m3g.Image2D;
import javax.microedition.m3g.Mesh;
import javax.microedition.m3g.Texture2D;
import javax.microedition.m3g.World;
import util.ImageHelper;
import util.MathHelper;
import util.ModelHelper;
import util.Rectangle;

/**
 *
 * @author Thinh
 */
public class Bike {
    public static final int SKEWANGLE_MAX = 30;
    private static final byte SKEWANGLE_STEP = 7;
    
    private Group gmBike;
    
    private byte skewAngle;
    private byte targetSkewAngle;
    private float moveStep, dieStep, posX, velocity, dieTurnVelocity;
    private Rectangle area;
    private boolean needUpdateSkewAngle = false;
    private byte sprayColor;
    
    private int timeline = 0;
    
    private World mWorld;
    private Play parent;
    
    public void requestUpdateSkewAngle() { needUpdateSkewAngle = true; }
    public float getSpeed() { return velocity; }
    
    public Bike(byte sprayColor, World _mWorld, Play _parent) {
        mWorld = _mWorld;
        parent = _parent;
        this.sprayColor = sprayColor;
        
        prepareResource();
    }
    
    private void prepareResource() {
        World bikeRes = ModelHelper.loadWorld("/models/bike.res");
        Mesh mBike = (Mesh)ModelHelper.extractNode(2, bikeRes);
        bikeRes = null;
        System.out.println("/models/bike"+sprayColor+".png");
        Image2D img2D = new Image2D(Image2D.RGB, ImageHelper.loadImage("/models/bike"+sprayColor+".png"));
        Texture2D tex2D = new Texture2D(img2D);
        Appearance mAppearance = new Appearance();
        mAppearance.setTexture(0, tex2D);
        mBike.setAppearance(0, mAppearance);
        mBike.setScale(1.8f, 1.8f, 1.8f);
        mBike.setOrientation(90, 0, 0, 1);
        mBike.postRotate(90, 0, 1, 0);
        mBike.postRotate(-90, 0, 0, 1);
        gmBike = new Group();
        gmBike.addChild(mBike);
        mWorld.addChild(gmBike);
    }
    
    public void reset() {
        skewAngle = 0;
        moveStep = 0;
        posX = 0;
        area = new Rectangle(-15, -45, 30, 90);
        gmBike.setOrientation(0, 1, 1, 1);
        gmBike.setTranslation(0, 30, 0);
    }
    
    public void updateRun() {
        if(needUpdateSkewAngle) {
            if(skewAngle <= targetSkewAngle - SKEWANGLE_STEP) {
                skewAngle += SKEWANGLE_STEP;
            } else if(skewAngle >= targetSkewAngle + SKEWANGLE_STEP) {
                skewAngle -= SKEWANGLE_STEP;
            } else {
                skewAngle = targetSkewAngle;
                needUpdateSkewAngle = false;
            }
            moveStep = -skewAngle * (velocity*0.006f+1.2f);
            gmBike.setOrientation(skewAngle, 0, 0, 1);
        }

        if(moveStep != 0) {
            posX += moveStep;
            area.transform(moveStep, 0);
            gmBike.translate(moveStep, 0, 0);
        }
        
        if(posX > 330 || posX < -330) {
            if(++timeline % 3 == 0) parent.flashWarning();
        } else parent.disableWarning();
        
        if(posX > 390 || posX < -390) gotoDie();
        
        checkCollision();
    }
    
    public void requestSpeedUp(float bikeMaxSpeed) {
        if(velocity == bikeMaxSpeed) {
            parent.setBonus();
            return;
        } else if(velocity < bikeMaxSpeed) setVelocity(velocity + 2);
        else if(velocity > bikeMaxSpeed) setVelocity(bikeMaxSpeed);
    }
    
    public void requestSlowDown(float bikeMinSpeed) {
        if(velocity == bikeMinSpeed) return;
        else if(velocity > bikeMinSpeed) setVelocity(velocity - 2);
        else if(velocity < bikeMinSpeed) setVelocity(bikeMinSpeed);
    }
    
    private void checkCollision() {
        Vector carList = parent.getCarList();
        for(int i = 0; i < carList.size(); i++) {
            Rectangle carArea = ((Car)carList.elementAt(i)).getArea();
            if(area.collisionWith(carArea)) {
                gotoDie();
                return;
            }
        }
    }
    
    public void gotoDie() {
        parent.setDie();
        gmBike.setOrientation(90, 0, 0, 1);
        gmBike.postRotate(MathHelper.rand(20, 90), 1, 0, 0);
        timeline = 0;
        dieTurnVelocity = -40;
        dieStep = velocity*-0.8f;
    }
    
    public void updateDie() {
        gmBike.translate(0, 0, dieStep);
        if(timeline < 28) {
            gmBike.postRotate(dieTurnVelocity, 1, 0, 0);
            dieTurnVelocity += 1.2f;
        }
        dieStep += velocity*0.02f;
    }
    
    public void updateSkewAngle(byte xData) {
        byte newSkewAngle = (byte)(xData*2);
        if(newSkewAngle != targetSkewAngle) {
            targetSkewAngle = newSkewAngle;
            requestUpdateSkewAngle();
        }
    }
    
    public void setVelocity(float value) {
        velocity = value;
        parent.updateBikeVelocity();
    }
}
