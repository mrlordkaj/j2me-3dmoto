/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Vector;
import javax.microedition.m3g.Group;
import javax.microedition.m3g.Mesh;
import util.CarPosition;
import util.MathHelper;
import util.Rectangle;

/**
 *
 * @author Thinh
 */
public class Car {
    private static final float TURN_ANGLE_RATE = 0.4f;
    private static final int TURN_FRAME = 5;
    public static final byte NUMBER_TYPE = 3;
    public static final byte TYPE_BUS = 0;
    public static final byte TYPE_TRUCK = 1;
    public static final byte TYPE_AUTO = 2;
    //public static final byte TYPE_RACER = 3;
    public static final byte LANE_LEFT = 0;
    public static final byte LANE_CENTER = 1;
    public static final byte LANE_RIGHT = 2;
    
    private float positionZ, positionX;
    private byte carType;
    private byte lane;
    private Rectangle carArea;
    private Mesh mCar;
    
    private boolean isRendered = false, turning = false, allowTurn = true;
    private byte turnStep, turnTimeline = 0, turnFrameMax;
    private float turnAngleStep;
    private short targetX;
    
    private Group mGroup;
    private Play parent;
    
    public int getLane() { return lane; }
    public float getPositionZ() { return positionZ; }
    public boolean canTurn() { return allowTurn; }
    public boolean isTurning() { return turning; }
    public Rectangle getArea() { return carArea; }
    
    public Car(byte lane, int relativePositionZ, int absolutePositionZ, Group mGroup, Play parent) {
        this.parent = parent;
        this.mGroup = mGroup;
        this.lane = lane;
        positionZ = absolutePositionZ;
        positionX = (this.lane-LANE_CENTER)*250;
        
        carType = (byte)MathHelper.rand.nextInt(NUMBER_TYPE);
        mCar = parent.getCarModel(carType);
        switch(carType) {
            case TYPE_BUS:
                carArea = new Rectangle(positionX - 100, positionZ - 220, 200, 440);
                break;
                
            case TYPE_TRUCK:
                carArea = new Rectangle(positionX - 100, positionZ - 260, 200, 520);
                break;
                
            case TYPE_AUTO:
                carArea = new Rectangle(positionX - 80, positionZ - 180, 160, 360);
                break;
        }
        this.mGroup.addChild(mCar);
        mCar.setRenderingEnable(false);
        mCar.setTranslation(positionX, 10, relativePositionZ);
    }
    
    public void update(float step) {
        positionZ += step;
        carArea.transform(0, step);
        
        //xóa những ô tô đã chạy qua
        if(positionZ >= 700) {
            mGroup.removeChild(mCar);
            parent.removeCar(this);
            return;
        }
        
        //chuyển từ ẩn sang hiện
        if(!isRendered && positionZ >= -6000) {
            isRendered = true;
            mCar.setRenderingEnable(true);
        }
        
        if(allowTurn && (positionZ > -5000 || positionZ > -2500)) {
            //thử xem muốn sang đường không
            if(parent.getLevel().wantTurn()) tryTurn();
            allowTurn = false;
        } else if(positionZ > -2700 && positionZ < -2500 && !turning) {
            allowTurn = true;
        }
        
        if(turning) updateTurning();
    }
    
    public void updateDie() {
        if(turning) updateTurning();
    }
    
    private void tryTurn() {
        int turnDirection = MathHelper.randomChance(50) ? -1 : 1;
        byte nextLane = (byte)(lane+turnDirection);
        if(nextLane < LANE_LEFT || nextLane > LANE_RIGHT) {
            turnDirection = -turnDirection;
            nextLane = LANE_CENTER;
        }
        
        Vector carList = parent.getCarList();
        //CarPosition carPosition = new CarPosition(nextLane, (int)positionZ);
        byte numCar = (byte)carList.size();
        byte checked = 0;
        for(byte i = 0; i < numCar; i++) {
            if(!checkAccident((Car)carList.elementAt(i))) checked++;
            else break;
            //Car nextCar = (Car)carList.elementAt(i);
            //if(!carPosition.checkAccident(nextCar.getLane(), (int)nextCar.getPositionZ())) checked++;
            //else break;
        }
        if(checked == numCar) {
            lane = nextLane;
            byte carTurnSpeed = parent.getLevel().getCarTurnSpeed();
            turnStep = (byte)(turnDirection*carTurnSpeed);
            turnFrameMax = (byte)(250/carTurnSpeed-1);
            turnTimeline = 0;
            turnAngleStep = (turnStep*-TURN_ANGLE_RATE)/TURN_FRAME;
            targetX = (short)((lane-LANE_CENTER)*250);
            turning = true;
        } else {
            turnDirection = 0;
        }
    }
    
    private void updateTurning() {
        if((turnStep > 0 && positionX >= targetX) || (turnStep < 0 && positionX <= targetX)) {
            //kiểm tra xem kết thúc sang đường chưa
            float comeback = targetX-positionX;
            mCar.translate(comeback, 0, 0);
            carArea.transform(comeback, 0);
            positionX = targetX;
            turning = false;
        } else {
            //thực hiện việc sang đường
            positionX += turnStep;
            carArea.transform(turnStep, 0);
            mCar.translate(turnStep, 0, 0);

            if(turnTimeline < turnFrameMax) {
                turnTimeline++;
                if(turnTimeline < TURN_FRAME) mCar.postRotate(turnAngleStep, 0, 0, 1);
                else if(turnTimeline > turnFrameMax-TURN_FRAME) mCar.postRotate(-turnAngleStep, 0, 0, 1);
            }
        }
    }
    
    public boolean checkAccident(Car target) {
        if(target.getLane() != lane) return false;
        
        if(target.getPositionZ() > positionZ+800 || target.getPositionZ() < positionZ-800) return false;
        
        return true;
    }
    
    public void dispose() {
        mGroup.removeChild(mCar);
    }
}
