/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Graphics;

/**
 *
 * @author Thinh
 */
public class SettingSystem extends SettingPage {
    
    public SettingSystem(Setting parent) {
        super(parent);
    }

    protected void prepareResource() {
        
    }

    public void paint(Graphics g) {
        g.setColor(0x00b4ff);
        g.fillRect(0, 0, Main.SCREENSIZE_WIDTH, Main.SCREENSIZE_HEIGHT);
        g.setFont(Play.BOLD_MEDIUM);
        g.setColor(0xffffff);
        g.drawString("Uncompleted feature!", Main.SCREENSIZE_WIDTH/2, Main.SCREENSIZE_HEIGHT/2+10, Graphics.HCENTER | Graphics.BASELINE);
    }

    public void pointerPressed(int x, int y) {
        
    }

    public void update() {
        
    }

    public void dispose() {
        
    }
}
