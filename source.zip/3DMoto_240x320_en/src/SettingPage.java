/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import javax.microedition.lcdui.Graphics;

/**
 *
 * @author Thinh
 */
public abstract class SettingPage {
    protected Setting parent;
    public SettingPage(Setting parent) {
        this.parent = parent;
        prepareResource();
    }
    protected abstract void prepareResource();
    public abstract void paint(Graphics g);
    public abstract void pointerPressed(int x, int y);
    public abstract void update();
    public abstract void dispose();
}
